import { NextRequest, NextResponse } from "next/server";
import { authenticateUser } from "@/db"; // Import the secure `authenticateUser` function from db.ts

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { username, password } = body;

    // Validate inputs
    if (!username || !password) {
      return NextResponse.json({ message: "Username and password are required" }, { status: 400 });
    }

    // Authenticate the user securely using the `authenticateUser` function
    const isAuthenticated = await authenticateUser(username, password);

    if (isAuthenticated) {
      return NextResponse.json({ message: "Login successful" }, { status: 200 });
    } else {
      return NextResponse.json({ message: "Invalid credentials" }, { status: 401 });
    }
  } catch (error) {
    console.error("Error during login:", error);
    return NextResponse.json({ message: "Internal Server Error" }, { status: 500 });
  }
}
