
import { NextRequest, NextResponse } from "next/server";
import { getProducts, addProduct, Product } from "@/db";

// Named export for GET request
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const searchTerm = url.searchParams.get("search");

    let products: Product[] = getProducts();

    if (searchTerm) {
      products = products.filter((product) =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return NextResponse.json(products);
  } catch (error) {
    console.error("Error fetching products:", error);
    return NextResponse.error();
  }
}

// Named export for POST request
export async function POST(req: NextRequest) {
  try {
    // Parse the request body (product details)
    const body = await req.json();
    const { name, description, price, imageUrl, category } = body;

    // Validate input (basic checks)
    if (!name || !description || !price || !imageUrl || !category) {
      console.error("Missing required fields:", { name, description, category, price, imageUrl });
      return NextResponse.json(
        { message: "Missing required fields" },
        { status: 400 }
      );
    }

    // Try adding the new product to the database
    addProduct(name, description,price, imageUrl, category);

    return NextResponse.json({ message: "Product added successfully" });
  } catch (error) {
    console.error("Error adding product:", error);
    return NextResponse.json({ message: "Error adding product" }, { status: 500 });
  }
}
