import { FeaturedProducts } from "@/components/featured-products";
import { HeroSection } from "@/components/hero-section";
import Image from "next/image";

export default function Home() {
  return (
    <>
    <HeroSection/>
    <FeaturedProducts/>
    </>
  );
}
