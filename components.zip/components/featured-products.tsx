"use client";
import { useEffect, useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface Product {
  id: number
  name: string
  price: number
  imageUrl: string
  description: string
  category: string
}

export function FeaturedProducts() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([])

  // Fetch products when the component mounts
  useEffect(() => {
    async function fetchProducts() {
      const res = await fetch('/api/products')
      const data = await res.json()
      setFeaturedProducts(data) // Set the fetched products to state
    }
    fetchProducts()
  }, [])

  return (
    <section className="w-full py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-8">Featured Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.length === 0 ? (
            <p className="text-center">Loading products...</p> // Loading message if products aren't available yet
          ) : (
            featuredProducts.map((product) => (
              <Card key={product.id} className="flex flex-col">
                <CardHeader>
                  <Image
                    src={product?.imageUrl} // Use the image URL from the database
                    alt={product.name}
                    width={300}
                    height={300}
                    className="w-full h-48 object-contain rounded-t-lg"
                  />
                </CardHeader>
                <CardContent className="flex-grow">
                  <CardTitle className="mb-2">{product.name}</CardTitle>
                  <p className="text-sm text-gray-600 mb-2">{product.description}</p>
                  <p className="font-bold text-lg">${product.price.toFixed(2)}</p>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white">
                    View More
                  </Button>
                </CardFooter>
              </Card>
            ))
          )}
        </div>
        <div className="text-center mt-8">
          <Button asChild variant="outline" className="bg-white text-blue-500 border-blue-500 hover:bg-blue-50">
            <Link href="/products">View All Products</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
