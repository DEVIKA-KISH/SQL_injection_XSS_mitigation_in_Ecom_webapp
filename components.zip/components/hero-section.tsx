'use client'

import { useEffect, useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { ArrowLeft, ArrowRight, RefreshCcw, Timer, ShoppingCart, User } from 'lucide-react'
import Link from "next/link"
import Image from "next/image"
import DOMPurify from 'dompurify'; // Added for sanitizing user input/output

const carouselItems = [
  {
    image: "/ps5-controller-dark.svg",
    discount: "Up to 25% off today",
    title: "Find great deals on the most popular video games and gaming consoles",
    link: "See more gaming deals"
  },
  {
    image: "/imac-back-dark.svg",
    discount: "Save 30% this week",
    title: "Exclusive deals on PC gaming accessories and hardware",
    link: "Browse PC deals"
  },
  {
    image: "/ipad-keyboard-dark.svg",
    discount: "Limited time offer",
    title: "Premium gaming chairs and desk setups on sale",
    link: "Shop gaming furniture"
  }
]

export function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [categories, setCategories] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [products, setProducts] = useState<any[]>([])
  const [isSearching, setIsSearching] = useState(false)

  useEffect(() => {
    async function fetchCategories() {
      try {
        const response = await fetch('/api/categories')
        const data = await response.json()
        setCategories(data)
      } catch (error) {
        console.error("Error fetching categories:", error)
      }
    }
    fetchCategories()

    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % carouselItems.length)
    }, 10000)

    return () => clearInterval(timer)
  }, [])

  const handleSearch = async () => {
    setIsSearching(true)
    try {
      // Sanitize search query to avoid sending potentially harmful input
      const sanitizedQuery = encodeURIComponent(searchQuery.trim())
      const response = await fetch(`/api/products?search=${sanitizedQuery}`)
      const data = await response.json()
      setProducts(data)
    } catch (error) {
      console.error("Error searching products:", error)
    }
  }

  return (
    <div className="w-full min-h-[calc(90vh-64px)] bg-gray-100 text-gray-900">
      <nav className="bg-white shadow-sm py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <Link href="/" className="flex items-center space-x-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6 text-blue-500"
            >
              <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
            </svg>
            <span className="text-xl font-bold">DK Store</span>
          </Link>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <ShoppingCart className="h-5 w-5" />
              <span className="sr-only">Cart</span>
            </Button>
            <Link href="/login">
              <User className="h-5 w-5" />
              <span className="sr-only">Login</span>
            </Link>
          </div>
        </div>
      </nav>
      <div className="container mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column */}
          <div className="space-y-8">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">
              Don&apos;t miss out on exclusive deals made for you.
            </h1>
            <p className="text-gray-600 flex items-center gap-2">
              <Timer className="h-5 w-5" />
              Free US delivery for orders over $200
            </p>

            {/* Search Section */}
            <div className="flex gap-2">
              <Select defaultValue="all">
                <SelectTrigger className="w-[180px] bg-white border-gray-200">
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All categories</SelectItem>
                  {categories.map((category, index) => (
                    <SelectItem key={index} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex-1 relative">
                <Input
                  type="search"
                  placeholder="Search entire store here"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-white border-gray-200"
                />
                <Button
                  className="absolute right-0 top-0 bottom-0 bg-blue-500 hover:bg-blue-600 text-white"
                  onClick={handleSearch}
                >
                  Search
                </Button>
              </div>
            </div>
          </div>

          {/* Right Column - Carousel */}
          <div className="relative bg-white shadow-sm rounded-2xl p-8">
            <div className="space-y-6">
              <Image
                src={carouselItems[currentSlide].image}
                alt="Promotional item"
                width={400}
                height={400}
                className="mx-auto"
              />
              <div className="space-y-4">
                <p className="inline-block bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm">
                  {carouselItems[currentSlide].discount}
                </p>
                <h2 className="text-xl font-semibold">
                  {carouselItems[currentSlide].title}
                </h2>
                <Link
                  href="#"
                  className="text-blue-600 hover:text-blue-700 flex items-center gap-2"
                >
                  {carouselItems[currentSlide].link}
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>

        {isSearching && (
          <div className="mt-8">
            {products.length > 0 ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {products.map((product) => (
                  <div key={product.id} className="bg-white shadow-sm p-6 rounded-lg">
                    <Image
                      src={product.imageUrl}
                      alt={product.name}
                      width={200}
                      height={200}
                      className="mx-auto w-full h-48 object-contain rounded-t-lg"
                    />
                    <h3 className="font-semibold mt-4">{product.name}</h3>
                    <p className="text-gray-600">${product.price}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p>
                Sorry, no products found for <strong>"{DOMPurify.sanitize(searchQuery)}"</strong>. {/* Sanitized */}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
